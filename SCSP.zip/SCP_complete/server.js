const fs = require("fs");
if (!fs.existsSync("uploads")) {
  fs.mkdirSync("uploads");
}

const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const multer = require("multer");
const jwt = require("jsonwebtoken");
const path = require("path");

const app = express();
const JWT_SECRET = "scp_campus_secret_2024_change_in_production";

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));
app.use(express.static("."));

// ── Upload config ──────────────────────────────────────────────
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/gif", "image/webp"];
const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname),
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (ALLOWED_TYPES.includes(file.mimetype)) cb(null, true);
    else cb(new Error("Only image files are allowed"));
  },
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

// ── Database ───────────────────────────────────────────────────
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "campus_portal",
});

db.connect((err) => {
  if (err) console.error("DB connection error:", err);
  else console.log("Connected to database");
});

// ── Auth middleware ────────────────────────────────────────────
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token provided" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}

function adminMiddleware(req, res, next) {
  authMiddleware(req, res, () => {
    if (req.user.role !== "admin")
      return res.status(403).json({ error: "Admin access required" });
    next();
  });
}

// ── LOGIN ──────────────────────────────────────────────────────
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: "Email and password required" });
  if (!email.endsWith("@university.edu.bd"))
    return res.status(400).json({ error: "Must use university email (@university.edu.bd)" });

  db.query("SELECT * FROM users WHERE email=?", [email], (err, result) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (result.length === 0)
      return res.status(401).json({ error: "Account not found. Please register." });

    const user = result[0];
    if (user.password !== password)
      return res.status(401).json({ error: "Incorrect password" });

    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name, role: user.role },
      JWT_SECRET,
      { expiresIn: "8h" }
    );
    res.json({ token, user: { id: user.id, name: user.name, role: user.role, email: user.email } });
  });
});

// ── REGISTER ───────────────────────────────────────────────────
app.post("/register", (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password || !name)
    return res.status(400).json({ error: "All fields required" });
  if (!email.endsWith("@university.edu.bd"))
    return res.status(400).json({ error: "Must use university email" });
  if (password.length < 6)
    return res.status(400).json({ error: "Password must be at least 6 characters" });

  db.query("SELECT id FROM users WHERE email=?", [email], (err, result) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (result.length > 0)
      return res.status(409).json({ error: "Account already exists. Please login." });

    db.query(
      "INSERT INTO users (email, name, password, role) VALUES (?,?,?,?)",
      [email, name, password, "student"],
      (err, r) => {
        if (err) return res.status(500).json({ error: "Could not create account" });
        const token = jwt.sign(
          { id: r.insertId, email, name, role: "student" },
          JWT_SECRET,
          { expiresIn: "8h" }
        );
        res.json({ token, user: { id: r.insertId, name, role: "student", email } });
      }
    );
  });
});

// ── REQUESTS ───────────────────────────────────────────────────
app.post("/request", authMiddleware, upload.single("image"), (req, res) => {
  const { title, description, category } = req.body;
  const image = req.file ? req.file.filename : null;
  if (!title || !description)
    return res.status(400).json({ error: "Title and description required" });

  db.query(
    "INSERT INTO requests (user_id, title, description, category, image, status) VALUES (?,?,?,?,?,?)",
    [req.user.id, title, description, category || "General", image, "Pending"],
    (err) => {
      if (err) return res.status(500).json({ error: "Could not submit request" });
      res.json({ message: "Request submitted successfully" });
    }
  );
});

app.get("/requests/my", authMiddleware, (req, res) => {
  db.query(
    "SELECT r.*, u.name as student_name FROM requests r JOIN users u ON r.user_id=u.id WHERE r.user_id=? ORDER BY r.id DESC",
    [req.user.id],
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(result);
    }
  );
});

app.get("/requests", adminMiddleware, (req, res) => {
  db.query(
    "SELECT r.*, u.name as student_name, u.email as student_email FROM requests r JOIN users u ON r.user_id=u.id ORDER BY r.id DESC",
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(result);
    }
  );
});

app.put("/request/:id", adminMiddleware, (req, res) => {
  const { status, admin_note } = req.body;
  db.query(
    "UPDATE requests SET status=?, admin_note=? WHERE id=?",
    [status, admin_note || null, req.params.id],
    (err) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json({ message: "Status updated" });
    }
  );
});

// ── FEEDBACK ───────────────────────────────────────────────────
app.post("/feedback", authMiddleware, (req, res) => {
  const { request_id, rating, comment } = req.body;
  if (!request_id || !rating)
    return res.status(400).json({ error: "Request ID and rating required" });

  db.query(
    "INSERT INTO feedback (user_id, request_id, rating, comment) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE rating=VALUES(rating), comment=VALUES(comment)",
    [req.user.id, request_id, rating, comment || ""],
    (err) => {
      if (err) return res.status(500).json({ error: "Could not submit feedback" });
      res.json({ message: "Feedback submitted" });
    }
  );
});

app.get("/feedback", adminMiddleware, (req, res) => {
  db.query(
    "SELECT f.*, u.name as student_name, r.title as request_title FROM feedback f JOIN users u ON f.user_id=u.id JOIN requests r ON f.request_id=r.id ORDER BY f.id DESC",
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(result);
    }
  );
});

// ── BOOKINGS ───────────────────────────────────────────────────
app.post("/booking", authMiddleware, (req, res) => {
  const { facility, date, time_slot, purpose } = req.body;
  if (!facility || !date || !time_slot)
    return res.status(400).json({ error: "Facility, date and time slot required" });

  db.query(
    "SELECT id FROM bookings WHERE facility=? AND date=? AND time_slot=? AND status != 'Cancelled'",
    [facility, date, time_slot],
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      if (result.length > 0)
        return res.status(409).json({ error: "This slot is already booked" });

      db.query(
        "INSERT INTO bookings (user_id, facility, date, time_slot, purpose, status) VALUES (?,?,?,?,?,?)",
        [req.user.id, facility, date, time_slot, purpose || "", "Confirmed"],
        (err) => {
          if (err) return res.status(500).json({ error: "Could not create booking" });
          res.json({ message: "Booking confirmed" });
        }
      );
    }
  );
});

app.get("/bookings/my", authMiddleware, (req, res) => {
  db.query(
    "SELECT * FROM bookings WHERE user_id=? ORDER BY date DESC",
    [req.user.id],
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(result);
    }
  );
});

app.get("/bookings", adminMiddleware, (req, res) => {
  db.query(
    "SELECT b.*, u.name as student_name FROM bookings b JOIN users u ON b.user_id=u.id ORDER BY b.date DESC",
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(result);
    }
  );
});

app.put("/booking/:id/cancel", authMiddleware, (req, res) => {
  db.query(
    "UPDATE bookings SET status='Cancelled' WHERE id=? AND user_id=?",
    [req.params.id, req.user.id],
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      if (result.affectedRows === 0)
        return res.status(404).json({ error: "Booking not found" });
      res.json({ message: "Booking cancelled" });
    }
  );
});

// ── ANNOUNCEMENTS ──────────────────────────────────────────────
app.post("/announcement", adminMiddleware, (req, res) => {
  const { title, message, priority } = req.body;
  if (!title || !message)
    return res.status(400).json({ error: "Title and message required" });

  db.query(
    "INSERT INTO announcements (title, message, priority, created_at) VALUES (?,?,?, NOW())",
    [title, message, priority || "normal"],
    (err) => {
      if (err) return res.status(500).json({ error: "Could not post announcement" });
      res.json({ message: "Announcement posted" });
    }
  );
});

app.get("/announcements", authMiddleware, (req, res) => {
  db.query(
    "SELECT * FROM announcements ORDER BY created_at DESC LIMIT 20",
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(result);
    }
  );
});

app.delete("/announcement/:id", adminMiddleware, (req, res) => {
  db.query("DELETE FROM announcements WHERE id=?", [req.params.id], (err) => {
    if (err) return res.status(500).json({ error: "Database error" });
    res.json({ message: "Deleted" });
  });
});

// ── EVENTS ─────────────────────────────────────────────────────
app.post("/event", adminMiddleware, (req, res) => {
  const { title, date, location, description } = req.body;
  if (!title || !date || !location)
    return res.status(400).json({ error: "Title, date and location required" });

  db.query(
    "INSERT INTO events (title, date, location, description) VALUES (?,?,?,?)",
    [title, date, location, description || ""],
    (err) => {
      if (err) return res.status(500).json({ error: "Could not create event" });
      res.json({ message: "Event created" });
    }
  );
});

app.get("/events", authMiddleware, (req, res) => {
  db.query(
    "SELECT * FROM events ORDER BY date ASC",
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(result);
    }
  );
});

app.delete("/event/:id", adminMiddleware, (req, res) => {
  db.query("DELETE FROM events WHERE id=?", [req.params.id], (err) => {
    if (err) return res.status(500).json({ error: "Database error" });
    res.json({ message: "Deleted" });
  });
});

// ── STATS (admin) ──────────────────────────────────────────────
app.get("/stats", adminMiddleware, (req, res) => {
  const queries = {
    total_requests: "SELECT COUNT(*) as c FROM requests",
    pending: "SELECT COUNT(*) as c FROM requests WHERE status='Pending'",
    completed: "SELECT COUNT(*) as c FROM requests WHERE status='Completed'",
    total_users: "SELECT COUNT(*) as c FROM users WHERE role='student'",
    total_bookings: "SELECT COUNT(*) as c FROM bookings",
    avg_rating: "SELECT ROUND(AVG(rating),1) as c FROM feedback",
  };

  const results = {};
  const keys = Object.keys(queries);
  let done = 0;

  keys.forEach((key) => {
    db.query(queries[key], (err, r) => {
      results[key] = err ? 0 : (r[0].c || 0);
      if (++done === keys.length) res.json(results);
    });
  });
});

// ── Admin: manage users ────────────────────────────────────────
app.get("/users", adminMiddleware, (req, res) => {
  db.query(
    "SELECT id, name, email, role FROM users ORDER BY id DESC",
    (err, result) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(result);
    }
  );
});

app.listen(3000, () => console.log("✅ SCP Server running on http://localhost:3000"));
