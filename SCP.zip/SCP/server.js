const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const multer = require("multer");

const app = express();

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));

// upload config
const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });

// database
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "campus_portal",
});

// ================= LOGIN (BD UNIVERSITY EMAIL) =================
app.post("/login", (req, res) => {
  const { email } = req.body;

  if (!email.endsWith("@university.edu.bd")) {
    return res.send("Invalid university email");
  }

  db.query("SELECT * FROM users WHERE email=?", [email], (err, result) => {
    if (result.length === 0) {
      db.query(
        "INSERT INTO users (email,name,role) VALUES (?,?,?)",
        [email, email.split("@")[0], "student"],
        (err, r) => {
          res.json({ user_id: r.insertId, name: email.split("@")[0] });
        }
      );
    } else {
      res.json({ user_id: result[0].id, name: result[0].name });
    }
  });
});

// ================= REQUEST =================
app.post("/request", upload.single("image"), (req, res) => {
  const { user_id, title, description } = req.body;
  const image = req.file ? req.file.filename : null;

  db.query(
    "INSERT INTO requests (user_id,title,description,image,status) VALUES (?,?,?,?,?)",
    [user_id, title, description, image, "Pending"],
    () => res.send("Submitted")
  );
});

app.get("/requests", (req, res) => {
  db.query("SELECT * FROM requests", (err, result) => res.json(result));
});

app.put("/request/:id", (req, res) => {
  db.query(
    "UPDATE requests SET status=? WHERE id=?",
    [req.body.status, req.params.id],
    () => res.send("Updated")
  );
});

// ================= FEEDBACK =================
app.post("/feedback", (req, res) => {
  const { user_id, request_id, rating, comment } = req.body;

  db.query(
    "INSERT INTO feedback (user_id,request_id,rating,comment) VALUES (?,?,?,?)",
    [user_id, request_id, rating, comment],
    () => res.send("Feedback added")
  );
});

// ================= BOOKING =================
app.post("/booking", (req, res) => {
  const { user_id, facility, date } = req.body;

  db.query(
    "INSERT INTO bookings (user_id,facility,date) VALUES (?,?,?)",
    [user_id, facility, date],
    () => res.send("Booked")
  );
});

// ================= ANNOUNCEMENT =================
app.post("/announcement", (req, res) => {
  db.query(
    "INSERT INTO announcements (title,message) VALUES (?,?)",
    [req.body.title, req.body.message],
    () => res.send("Announcement added")
  );
});

// ================= EVENTS =================
app.post("/event", (req, res) => {
  db.query(
    "INSERT INTO events (title,date,location) VALUES (?,?,?)",
    [req.body.title, req.body.date, req.body.location],
    () => res.send("Event created")
  );
});

app.listen(3000, () => console.log("Server running on 3000"));